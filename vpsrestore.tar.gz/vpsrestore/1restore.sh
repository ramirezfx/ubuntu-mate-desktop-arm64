#!/bin/sh
dconf load /org/mate/ < mate-restore
dconf load /net/launchpad/plank/docks/ < plank-restore
tar xzf overlay.tar.gz
cp -Rfa overlay/.config/plank ~/.config/
cp -Rfa overlay/.local/share/* ~/.local/share/
ln -s /data ~/data
rm -Rf overlay
